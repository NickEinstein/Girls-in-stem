import React from 'react';
import Cookies from 'universal-cookie'
import useEffect from 'react'
import { useHistory } from 'react-router-dom';




const cookie = new Cookies();
const Logout = ({history}) => {


    


    return (
        <div>
            
        </div>
    );
};

export default Logout;
